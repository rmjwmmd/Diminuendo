A mod produced by rmjwmmd.

If you have any suggestions, feedback or anything else feel free to reach out to me on Discord, either in DMs or in the modding channels of the
Monster Girl Dreams discord.

Hope you enjoy!

What comes next: I will be working on something fairly long-term with the next major update to the mod by having monster girls be able to capture you long term.
I will work on updates to give normal events and scenes to other monster girls and expand what I can while working on the bigger content.

Walkthrough:

To unlock all content you must beat the Labyrinth in the main story and get the Labyrinth Checkpoint Gem.
The first quest is in the Forest and is titled Cut Down To Size. Complete this and you unlock all events for the mod.

The story for the mod is done through the quests page in the Mystic Forest for Gren, then twice to the Temple for Aiko and Shizu.
Then, while in town go to Vivian and Amber for their quests, buried in their talk options.

In between each quest remember to talk to Elly to turn in your item and receive a new one.

Once you have completed Amber's quest return to Elly and unlock a new quest in the Caverns.

Once you have defeated the Size Coven you can revisit their lair from the overworld map and revisit old cutscenes from the quests.

Support me on Patreon if you enjoy my work!
https://patreon.com/rmjwmmd

5.2 Update: Adds new quests to fight Gwen and Haruka. Gwen is waiting at the Willpower Temple and Haruka is waiting in the Caverns. Simply select their quests after fighting them in their respective Forest and Mountain Quests.
Defeating Gwen will give an important Key Item for future content so I highly recommend defeating her before future updates later this year. Once both have been defeated, they will be waiting at the tunnel leading to the Capital and you can easily refight them there.
The finale to the Futa Gals storyline will come closer to summertime, please be excited.

5.3 Update: Adds 4 new events to monster girls that I have not done content for before. 1 New Event for the Alraune in the Forest, titled Flower Fields
3 Event Additions, requiring you to visit the Bubble Slime through the Fizzy Springs event, Visit Amy from the World Map, and visiting Bed-Chan just before Aiko's room.

Due to an oversight, the rune from Haruka's quest did not drop properly. Please use the provided console command to give yourself this rune if you already missed it.

player.inventory.give("Rune of Super Saiyan", 1)

If you do not know how to activate console commands, please see this guide on the wiki. https://monstergirldreams.miraheze.org/wiki/Console

5.4 Update: Go to the mountains and select Beris' Tough Training Event and lose to her in a fight. You will be taken to the Labyrinth and given the choice of who to go with.

5.45 Update: New Event in Caverns: Haunting Caverns features Ghost and mouthplay, trip through the body at the end but not only for 1 line. 
Camilla and Jora scenes accessed through Spider Cave and Meet with Jora events. Himika event through Breaking the Oni Event in the Temple.